package org.seethrough.glass

import javax.mail.*
import javax.mail.search.*
import java.util.Properties
import java.security.*
import org.springframework.beans.factory.InitializingBean

import static javax.mail.Flags.Flag.*

class MailService implements InitializingBean {
	def transactional = false
	
	def grailsApplication
	def jmsService
	
	def config

	void afterPropertiesSet() {
		readConfig()
	}
	
	void readConfig() {
		config = grailsApplication.mergedConfig.grails.plugin.glass
	}

	def readMail() {	
		def session = Session.getDefaultInstance(new Properties(), null)
		def store = session.getStore("imaps")
		def inbox

		try {
			inbox = openInbox(store)

			def messages = unseenMails(inbox)
			messages.each { msg ->
				sendJMSMessage(msg)
				msg.setFlag(SEEN, true)
			}
		} catch (Exception e) {
			log.error e
			throw e
		} finally {
			inbox?.close(true)
			store.close()
		}

	}

	private sendJMSMessage(msg) {
		def jmsMsg = emailToJMSMessage(msg)
		jmsService.send(topic: 'email', jmsMsg)
		log.info "Sending " + jmsMsg
	}

	private Folder openInbox(Store store) {
		store.connect(
				config.host,
				config.username,
				config.password)
		def inbox = store.getFolder("Inbox")
		inbox.open(Folder.READ_WRITE)
		return inbox
	}
	
	def unseenMails(inbox) { 
		inbox.search(new FlagTerm(new Flags(SEEN), false))
	}
	
	def emailToJMSMessage(msg) {
		def map = new HashMap<String, String>()
		map << [from: msg.from[0].getAddress(), subject: msg.subject, body: msg.contentStream.getText().trim()]
		return map
	}
}
