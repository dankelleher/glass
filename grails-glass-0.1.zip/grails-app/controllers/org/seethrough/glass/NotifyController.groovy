package org.seethrough.glass

import grails.converters.JSON

class NotifyController {

	def notifyService
	def jmsService
	
    def index() {
		def message = request.JSON
		def userId = message.userToken
		def timelineItemId = message.itemId
		
		def text = notifyService.getMessage(userId, timelineItemId)
		
		Log.error "Received reply: " + text
		
		render "OK"
	}
}
