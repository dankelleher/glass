package org.seethrough.glass

/**
 * Copyright: Daniel Kelleher Date: 02.06.13 Time: 23:42
 */
class UserCredential {
    User user

    String accessToken
    String refreshToken
    Long expirationTimeMilliseconds

}
